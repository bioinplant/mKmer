from __future__ import absolute_import 

from mKmer.version import __version__
